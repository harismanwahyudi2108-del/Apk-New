package com.vcringan.hd;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_PERMISSIONS = 1001;
    private static final int REQ_FILE_CHOOSER = 1002;

    /* File HTML ditanam langsung di dalam APK dan disajikan lewat origin HTTPS lokal yang aman untuk WebRTC */
    private static final String LOCAL_APP_URL = "https://appassets.androidplatform.net/assets/index.html";

    private static final String CHANNEL_CHAT_ID = "vc_ringan_chat_high";
    private static final String CHANNEL_CALL_ID = "vc_ringan_call_high";
    private static final int NOTIF_CALL_ID = 9001;
    private static final String EXTRA_OPEN_PEER = "open_peer_id";

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private AudioManager audioManager;
    private NotificationManager notificationManager;
    private PermissionRequest pendingWebPermission;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean isAppForeground = true;
    private int chatNotifSeq = 2000;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannels();

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = findViewById(R.id.webview);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        webView.addJavascriptInterface(new NativeBridge(), "AndroidNative");

        webView.setWebViewClient(new WebViewClient() {
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("https://appassets.androidplatform.net/") || url.startsWith("http://") || url.startsWith("https://"))) {
                    return false;
                }
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(i);
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (hasMediaPermissions()) {
                            request.grant(request.getResources());
                        } else {
                            pendingWebPermission = request;
                            requestAllPermissions();
                        }
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams fileChooserParams) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Gagal membuka pemilih file.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        requestAllPermissions();
        webView.loadUrl(LOCAL_APP_URL);
    }

    @Override
    protected void onResume() {
        super.onResume();
        isAppForeground = true;
    }

    @Override
    protected void onPause() {
        isAppForeground = false;
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.hasExtra(EXTRA_OPEN_PEER)) {
            final String peerId = intent.getStringExtra(EXTRA_OPEN_PEER);
            if (peerId != null && !peerId.isEmpty() && webView != null) {
                final String safeId = peerId.replaceAll("[^a-zA-Z0-9_-]", "");
                webView.post(new Runnable() {
                    @Override
                    public void run() {
                        webView.evaluateJavascript(
                                "if(window.openPeerFromNotification){window.openPeerFromNotification('" + safeId + "');}",
                                null
                        );
                    }
                });
            }
        }
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && notificationManager != null) {
            NotificationChannel chatChannel = new NotificationChannel(
                    CHANNEL_CHAT_ID,
                    "Pesan Chat Masuk",
                    NotificationManager.IMPORTANCE_HIGH
            );
            chatChannel.setDescription("Notifikasi layar atas untuk pesan chat VC Ringan HD");
            chatChannel.enableVibration(true);
            chatChannel.setVibrationPattern(new long[]{0, 180, 100, 180});
            notificationManager.createNotificationChannel(chatChannel);

            NotificationChannel callChannel = new NotificationChannel(
                    CHANNEL_CALL_ID,
                    "Panggilan Masuk",
                    NotificationManager.IMPORTANCE_HIGH
            );
            callChannel.setDescription("Notifikasi layar atas untuk telepon suara dan video call masuk");
            callChannel.enableVibration(true);
            callChannel.setVibrationPattern(new long[]{0, 400, 200, 400});
            notificationManager.createNotificationChannel(callChannel);
        }
    }

    private void postHeadsUpNotification(String title, String body, boolean isCall, String peerId, boolean forceShow) {
        if (notificationManager == null) return;
        if (!forceShow && isAppForeground && !isCall) return;

        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }

        try {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            if (!isCall && peerId != null && !peerId.isEmpty()) {
                intent.putExtra(EXTRA_OPEN_PEER, peerId);
            }

            int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                piFlags |= PendingIntent.FLAG_IMMUTABLE;
            }

            int reqCode = isCall ? NOTIF_CALL_ID : (++chatNotifSeq);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, reqCode, intent, piFlags);

            String channelId = isCall ? CHANNEL_CALL_ID : CHANNEL_CHAT_ID;
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(isCall ? NotificationCompat.CATEGORY_CALL : NotificationCompat.CATEGORY_MESSAGE)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent);

            int notifId = isCall ? NOTIF_CALL_ID : reqCode;
            notificationManager.notify(notifId, builder.build());
        } catch (Exception ignored) {
        }
    }

    private void openAppNotificationSettings() {
        try {
            Intent intent = new Intent();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                intent.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            } else {
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.fromParts("package", getPackageName(), null));
            }
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Buka Pengaturan -> Aplikasi -> VC Ringan HD -> Notifikasi.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean hasMediaPermissions() {
        boolean cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        return cam && mic;
    }

    private void requestAllPermissions() {
        List<String> needed = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSIONS && pendingWebPermission != null) {
            if (hasMediaPermissions()) {
                pendingWebPermission.grant(pendingWebPermission.getResources());
            } else {
                pendingWebPermission.deny();
                Toast.makeText(this, "Izin kamera & mikrofon wajib diaktifkan.", Toast.LENGTH_LONG).show();
            }
            pendingWebPermission = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE_CHOOSER) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("(function(){ return window.handleAndroidBack ? window.handleAndroidBack() : false; })();", new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    if ("true".equals(value)) {
                        return;
                    }
                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        MainActivity.super.onBackPressed();
                    }
                }
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        resetAudioNormal();
        super.onDestroy();
    }

    private void applyAudioRoute(boolean inCall, boolean speakerOn) {
        if (audioManager == null) return;
        try {
            if (inCall) {
                audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);
                if (Build.VERSION.SDK_INT >= 31) {
                    Api31AudioHelper.setRoute(audioManager, speakerOn);
                }
                audioManager.setSpeakerphoneOn(speakerOn);
            } else {
                resetAudioNormal();
            }
        } catch (Exception ignored) {
        }
    }

    private void resetAudioNormal() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                Api31AudioHelper.clearRoute(audioManager);
            }
            audioManager.setSpeakerphoneOn(false);
            audioManager.setMode(AudioManager.MODE_NORMAL);
            setVolumeControlStream(AudioManager.STREAM_MUSIC);
        } catch (Exception ignored) {
        }
    }

    @TargetApi(31)
    private static class Api31AudioHelper {
        static void setRoute(AudioManager am, boolean speakerOn) {
            try {
                int targetType = speakerOn ? AudioDeviceInfo.TYPE_BUILTIN_SPEAKER : AudioDeviceInfo.TYPE_BUILTIN_EARPIECE;
                List<AudioDeviceInfo> devices = am.getAvailableCommunicationDevices();
                for (AudioDeviceInfo dev : devices) {
                    if (dev.getType() == targetType) {
                        am.setCommunicationDevice(dev);
                        return;
                    }
                }
            } catch (Exception ignored) {
            }
        }

        static void clearRoute(AudioManager am) {
            try {
                am.clearCommunicationDevice();
            } catch (Exception ignored) {
            }
        }
    }

    public class NativeBridge {
        @JavascriptInterface
        public void setCallAudioMode(final boolean inCall, final boolean speakerOn) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applyAudioRoute(inCall, speakerOn);
                }
            });
        }

        @JavascriptInterface
        public void setKeepScreenOn(final boolean keepOn) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (keepOn) {
                        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    } else {
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                }
            });
        }

        @JavascriptInterface
        public void showNotification(final String title, final String body, final boolean isCall, final String peerId, final boolean forceShow) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    postHeadsUpNotification(title, body, isCall, peerId, forceShow);
                }
            });
        }

        @JavascriptInterface
        public void cancelCallNotification() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (notificationManager != null) {
                        notificationManager.cancel(NOTIF_CALL_ID);
                    }
                }
            });
        }

        @JavascriptInterface
        public void openNotificationSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openAppNotificationSettings();
                }
            });
        }

        @JavascriptInterface
        public void sharePlainText(final String title, final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent sendIntent = new Intent(Intent.ACTION_SEND);
                        sendIntent.setType("text/plain");
                        sendIntent.putExtra(Intent.EXTRA_SUBJECT, title);
                        sendIntent.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(sendIntent, title));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Gagal membuka menu bagikan.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void shareBackupText(final String filename, final String jsonContent) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent sendIntent = new Intent(Intent.ACTION_SEND);
                        sendIntent.setType("text/plain");
                        sendIntent.putExtra(Intent.EXTRA_SUBJECT, filename);
                        sendIntent.putExtra(Intent.EXTRA_TEXT, jsonContent);
                        startActivity(Intent.createChooser(sendIntent, "Simpan / Kirim Backup VC Ringan"));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Gagal membagikan backup.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}
